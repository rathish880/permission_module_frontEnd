<template>
    <div data-theme="winter" class="h-screen flex flex-col gap-4 ">
        <NuxtPage />
    </div>
</template>
